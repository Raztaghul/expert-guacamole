# Faraya: Mapping Proc_Persons

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
npx http-server
# Then, visit http://localhost:8080.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with 078e6557eb434a15.js, which contains the notebook compiled as an
ES module.

*Exported from version 267 of [Faraya: Mapping Proc_Persons](https://observablehq.com/d/078e6557eb434a15) on observablehq.com.*